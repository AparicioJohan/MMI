library(testthat)
library(MrBean)

test_check("MrBean")
