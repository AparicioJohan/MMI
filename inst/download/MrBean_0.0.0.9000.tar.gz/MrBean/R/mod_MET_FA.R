#' MET_FA UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_MET_FA_ui <- function(id){
  ns <- NS(id)
  tagList(
    div(id=ns("notfound"),
        rep_br(2),
        HTML("<center><img src='www/code.svg' width='60%' height='60%'></center>")
    ),
    
    shinyjs::hidden(
      div(id=ns("second"),  
          fluidRow(
            column(6,
                   fluidRow(
                     bs4TabCard(width = 12,id = "MET_fa",tabStatus = "light",maximizable = T,solidHeader = T,closable = F,
                                status ="success", 
                                bs4TabPanel(tabName = "Genotypic Variance", active = T,
                                            shinycssloaders::withSpinner(
                                              echarts4r::echarts4rOutput(ns("g1")),type = 5,color = "#28a745"
                                              )
                                            # fluidRow(
                                            #   col_3(),
                                            #   col_6(
                                            #     actionBttn(inputId = ns("dendo"),label = "Dendogram",style = "jelly",color = "warning",block = T, icon = icon("check") )
                                            #   ),
                                            #   col_3()
                                            # )
                                ),
                                bs4TabPanel(tabName = "Variance Explained",icon = icon("signal"),
                                            shinycssloaders::withSpinner(
                                              echarts4r::echarts4rOutput(ns("g2")),
                                              type = 5,color = "#28a745")
                                )
                     )
                   ),
                   fluidRow(
                     bs4Card(
                       pickerInput(
                         inputId = ns("geno_filter2"),
                         label = "Search Genotype:", 
                         choices = "",
                         options = list(
                           `live-search` = TRUE, size = 5), width = "100%"
                       ),
                       actionBttn(
                         inputId = ns("search2"),
                         label = "Search",
                         style = "fill", 
                         color = "primary",size = "sm"
                       ), rep_br(2),
                       shinycssloaders::withSpinner(
                         echarts4r::echarts4rOutput(ns("g3")),
                         type = 5,color = "#28a745"),
                       br(),
                       downloadButton(ns("downloadSC"), 
                                      "Download Scores",
                                      class="btn-success",
                                      style= " color: white ; background-color: #28a745; float:left"),
                       width = 12,title = tagList(icon=icon("exchange-alt"), "Scores"),status = "success",solidHeader = TRUE
                     )
                   )
            ),
            column(6,
                   fluidRow(
                     bs4Card(
                       shinycssloaders::withSpinner(
                         echarts4r::echarts4rOutput(ns("g4")),
                         type = 5,color = "#28a745"
                         ),
                       br(),
                       actionBttn(
                         inputId = ns("lat"), 
                         label = "Latent Regression",
                         style = "minimal", 
                         color = "success",
                         icon = icon("chart-pie")
                       ),
                       width = 12,title = tagList(icon=icon("chart-line"), "Total Variance"),
                       status = "success",solidHeader = TRUE, maximizable = T
                     )
                   ),
                   fluidRow(
                     bs4Card(
                         shinycssloaders::withSpinner(
                           echarts4r::echarts4rOutput(ns("g5")),
                           type = 5,color = "#28a745"),
                         br(),
                         downloadButton(ns("downloadLO"), 
                                        "Download Loadings",
                                        class="btn-success",
                                        style= " color: white ; background-color: #28a745; float:left"),
                       width = 12,title = tagList(icon=icon("exchange-alt"), "Loadings"),status = "success",solidHeader = TRUE
                     )
                   )
            )
          )
          # fluidRow(
          #   column(12,
          #          fluidRow(
          #            bs4Card(
          #              shinycssloaders::withSpinner(
          #                plotly::plotlyOutput(ns("plotblup2")),
          #                type = 5,color = "#28a745"
          #              ),
          #              title = "Genotype Effects", solidHeader =  TRUE,status = "success",width = 12,collapsed = F)
          #          )
          #   )
          # )
      )
    )  
  )
}
    
#' MET_FA Server Function
#'
#' @noRd 
mod_MET_FA_server <- function(input, output, session, model){
  ns <- session$ns
  
  # observeEvent(model$run(),{
  #   toggle(id = "notfound", condition = is.null(model$model()) )
  #   toggle(id = "second", condition = !is.null(model$model()) )
  # })
 
  observeEvent(model$run(),{
    toggle(id = "notfound", condition = length(grep("fa", model$model()$mod$call))==0)
    toggle(id = "second", condition = length(grep("fa", model$model()$mod$call))!=0)
  }, ignoreInit = T, ignoreNULL = T)
  
  
  output$g1 <-  echarts4r::renderEcharts4r({
    req(model$model())
    mod <- model$model()$mod
    req(length(grep("fa", model$model()$mod$call))!=0)
    ASM <- try(fa.asreml( mod , trunc.char = NULL), silent = T )
    if(class(ASM)=="try-error") return()
    genVarChart(mod, height = "65%")
  })
  
  output$g2 <-  echarts4r::renderEcharts4r({
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    mod <- model$model()$mod
    varExpChart(mod, height = "65%")
  })


  observeEvent(model$run(),{
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    mod <- model$model()$mod
    sc <- scoreChart(mod, x = "Comp1", y = "Comp2", plot=F)
    inx <- as.character(unique(sc$gen))
    updatePickerInput(session = session, inputId = "geno_filter2", choices = inx)
  }, ignoreInit = T, ignoreNULL = T)

  output$g3 <-  echarts4r::renderEcharts4r({
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    input$search2
    isolate({
      req(input$geno_filter2)
      mod <- model$model()$mod
      scoreChart(mod, x = "Comp1", y = "Comp2", gen = input$geno_filter2)
    })

  })

  output$g4 <-  echarts4r::renderEcharts4r({
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    mod <- model$model()$mod
    waterChart(mod)
  })

  output$g5 <-  echarts4r::renderEcharts4r({
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    mod <- model$model()$mod
    loadChart(mod, x = "fac_1", y = "fac_2")
  })


  observeEvent(input$lat,{
    req(model$model())
    bm <- model$model()$predictions
    lvl <- as.character(unique(bm$gen))
    updatePickerInput(session = session, inputId = "geno_filter", choices = lvl, selected = lvl[1:2])
  })

  output$regress <- renderPlot({
    # input$lat
    input$search
    input$scale
    input$text_lab
    input$alpha_p
    isolate({
      req(model$model())
      req(length(grep("fa", model$model()$mod$call))!=0)
      validate(need(input$geno_filter, message = "Please select at least one genotype."  ) )
      mod <- model$model()$mod
      gen <- input$geno_filter
      latent_regress(mod, gen, input$scale, input$text_lab, input$alpha_p)
    })
  })


  observeEvent(input$lat,{
    showModal(modalDialog(
      title = tagList(icon=icon("chart-bar"), "Latent Regression"), size = "l", easyClose = T,
      pickerInput(
        inputId = ns("geno_filter"),
        label = "Search Genotype:",
        choices = "", multiple = T,
        options = list(
          `live-search` = TRUE, size = 5), width = "100%"
      ),
      actionBttn(
        inputId = ns("search"),
        label = "Search",
        style = "fill",
        color = "primary",size = "sm"
      ), rep_br(2),
      shinycssloaders::withSpinner(
        plotOutput(ns("regress")),type = 6,color = "#28a745"
      ),
      fluidRow(
        col_3(
        ),
        col_3(
          switchInput(
            inputId = ns("scale"),
            label = "Fixed Scale",
            labelWidth = "100%",
            onStatus = "success",
            offStatus = "danger",
            width = "100%", value = TRUE
          )
        ),
        col_3(
          switchInput(
            inputId = ns("text_lab"),
            label = "Labels",
            labelWidth = "100%",
            onStatus = "success",
            offStatus = "danger",
            width = "100%", value = F
          )
        )
      ),
      fluidRow(
        col_3(),
        col_6(
          sliderTextInput(
            inputId = ns("alpha_p"), label = "Choose alpha:", 
            choices = seq(0.05,1, by = 0.1), 
            grid = TRUE, selected = 0.55, width = "100%"
          )
        ),
        col_3()
      ), 
      footer = tagList(
        downloadButton(ns("downloadFA"), 
                       "Download Table",
                       class="btn-success",
                       style= " color: white ; background-color: #28a745; float:left"),
        modalButton("Cancel")
      )
    )
    )
  }, ignoreInit = T, ignoreNULL = T)
  
  

  # Downloads ---------------------------------------------------------------

  
  
  fa_components <- reactive({
    req(model$model())
    req(length(grep("fa", model$model()$mod$call))!=0)
    mod <- model$model()$mod
    datos <- latent_regress(mod,return_data = T)
    return(datos)
  })  
  
  
  output$downloadFA <- downloadHandler(
    filename = function() {
      paste("FA_loadings_scores_mrbean", ".csv", sep = "")
    },
    content = function(file) {
      write.csv(fa_components(), file, row.names = FALSE)
    }
  )
  
  output$downloadSC <- downloadHandler(
    filename = function() {
      paste("FA_scores_mrbean", ".csv", sep = "")
    },
    content = function(file) {
      req(model$model())
      req(length(grep("fa", model$model()$mod$call))!=0)
      model <- model$model()$mod
      ASM <- fa.asreml( model , trunc.char = NULL)
      ASM <- ASM$blups[[1]]$scores
      names(ASM)[c(1,2,4)] <- c("score", "component" ,"score_rotated")
      write.csv(ASM, file, row.names = FALSE)
    }
  )
  
  output$downloadLO <- downloadHandler(
    filename = function() {
      paste("FA_loadings_mrbean", ".csv", sep = "")
    },
    content = function(file) {
      req(model$model())
      req(length(grep("fa", model$model()$mod$call))!=0)
      model <- model$model()$mod
      ASM <- fa.asreml( model , trunc.char = NULL)
      ASM <- ASM$gammas[[1]]$`rotated loads`
      write.csv(ASM, file, row.names = T)
    }
  )

  
}
    
## To be copied in the UI
# mod_MET_FA_ui("MET_FA_ui_1")
    
## To be copied in the server
# callModule(mod_MET_FA_server, "MET_FA_ui_1")
 
